# Frequently Asked Questions

### Who are the maintainers?

The HashiCorp Terraform Kubernetes provider team is:

* Phil Sautter, Product Manager - [@redeux](https://github.com/redeux)
* Alex Somesan, Engineer - [@alexsomesan](https://github.com/alexsomesan)
* John Houston, Engineer - [@jrhouston](https://github.com/jrhouston)
* Stef Forrester, Engineer - [@dak1n1](https://github.com/dak1n1)
* Aareet Shermon, Engineering Manager - [@aareet](https://github.com/aareet)