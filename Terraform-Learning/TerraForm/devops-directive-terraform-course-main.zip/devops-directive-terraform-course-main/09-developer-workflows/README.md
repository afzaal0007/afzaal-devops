- CI/CD
- Multi account / project
- Terragrunt
- Test account + cloud nuke

`.github/workflows contains CI/CD Workflows`

https://github.com/hashicorp/learn-terraform-github-actions/blob/master/.github/workflows/terraform.yml

