Follow: [https://github.com/traefik/traefik/blob/v1.7/docs/user-guide/kubernetes.md](https://github.com/traefik/traefik/blob/v1.7/docs/user-guide/kubernetes.md)
